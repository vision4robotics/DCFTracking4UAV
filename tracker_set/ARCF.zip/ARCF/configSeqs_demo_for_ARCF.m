function seqs=configSeqs_demo_for_ARCF

seqUAV123_10fps_person12_1 = {struct('name','person12_1','path','.\seq\person12\','startFrame',1,'endFrame',201,'nz',6,'ext','jpg','init_rect',[0,0,0,0])};
seqUAV123_10fps_truck4_1 = {struct('name','truck4_1','path','.\seq\truck4\','startFrame',1,'endFrame',193,'nz',6,'ext','jpg','init_rect',[0,0,0,0])};
seqUAV123_10fps_truck4_2 = {struct('name','truck4_2','path','.\seq\truck4\','startFrame',193,'endFrame',421,'nz',6,'ext','jpg','init_rect',[0,0,0,0])};
seqUAV123_10fps_wakeboard7 = {struct('name','wakeboard7','path','.\seq\wakeboard7\','startFrame',1,'endFrame',67,'nz',6,'ext','jpg','init_rect',[0,0,0,0])};
seqUAV123_10fps_wakeboard10 = {struct('name','wakeboard10','path','.\seq\wakeboard10\','startFrame',1,'endFrame',157,'nz',6,'ext','jpg','init_rect',[0,0,0,0])};
seqUAV123_10fps_boat1 = {struct('name','boat1','path','.\seq\boat1\','startFrame',1,'endFrame',301,'nz',6,'ext','jpg','init_rect',[0,0,0,0])};
seqUAV123_10fps_building4 = {struct('name','building4','path','.\seq\building4\','startFrame',1,'endFrame',263,'nz',6,'ext','jpg','init_rect',[0,0,0,0])};

seqs = seqUAV123_10fps_building4; 
