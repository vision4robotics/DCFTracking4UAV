% By Jianming Zhang
% usage: feature = calIIF(I,kernel_size,nbins)