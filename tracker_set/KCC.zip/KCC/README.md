# Visual Tracking Using Kernel Cross-Correlator (KCC)

This tracker can be inserted into the tracker benchmark (MATLAB version) directly:

    https://sites.google.com/site/trackerbenchmark/benchmarks/v10

To run it, you may download the whole repo as:

        git clone https://github.com/wang-chen/KCC.git

Then put it into the tracker folder and follow the instructions of the benchmark.
